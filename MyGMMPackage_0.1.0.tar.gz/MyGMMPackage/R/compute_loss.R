#' Compute the Log-Loss for the EM Algorithm
#'
#' This function calculates the log-likelihood (log-loss) for the Gaussian Mixture Model
#' given the current parameters (proportions, means, and covariances) and the data.
#'
#' @param X A matrix or data frame of observations where rows are samples and columns are features.
#' @param K An integer specifying the number of components (clusters) in the Gaussian Mixture Model.
#' @param proportions A vector of the mixing proportions for each Gaussian component.
#' @param mu A list of mean vectors for each Gaussian component.
#' @param sigma A list of covariance matrices for each Gaussian component.
#' @return A numeric value representing the log-likelihood (log-loss) of the Gaussian Mixture Model
#'   given the current parameters and data.
#' @export

compute_loss <- function(X, K, proportions, mu, sigma) {
  nb_observations <- dim(X)[1]
  likelihoods <- matrix(0, nrow = nb_observations, ncol = K)
  epsilon <- 1e-6

  for (k in 1:K) {
    likelihoods[, k] <- proportions[k] * dmvnorm(X, mean = mu[[k]], sigma = sigma[[k]] + epsilon)
  }

  log_loss <- sum(log(rowSums(likelihoods)))
  return(log_loss)
}
