#' M-Step of the Expectation-Maximization Algorithm
#'
#' The M-step updates the model parameters, including the proportions, means, and covariances of
#' the Gaussian components, based on the responsibilities computed in the E-step.
#'
#' @param X A matrix or data frame of observations where rows are samples and columns are features.
#' @param t_i_k A matrix of responsibilities (posterior probabilities), where each row corresponds
#'   to a data point and each column corresponds to a Gaussian component.
#' @param model A string indicating the type of model to be used. Defaults to "basic", but can be
#'   extended for other variants of GMMs (e.g., "full", "diag").
#' @return A list containing the updated model parameters:
#'   \item{proportions}{A vector of mixing proportions for each Gaussian component.}
#'   \item{mu}{A list of mean vectors for each Gaussian component.}
#'   \item{sigma}{A list of covariance matrices for each Gaussian component.}
#' @export

M_step <- function(X, t_i_k, model = "basic") {
  nb_observations <- dim(X)[1]
  nb_features <- dim(X)[2]
  K <- dim(t_i_k)[2]

  proportions <- colSums(t_i_k) / nb_observations
  mu <- vector("list", length = K)
  sigma <- vector("list", length = K)

  for (k in 1:K) mu[[k]] <- colSums(t_i_k[, k] * X) / sum(t_i_k[, k])

  for (k in 1:K) {
    diff <- sweep(X, 2, mu[[k]], "-")
    sigma[[k]] <- t(diff) %*% (diff * t_i_k[, k]) / sum(t_i_k[, k])
  }

  return(list(proportions = proportions, mu = mu, sigma = sigma))
}
