#' E-Step of the Expectation-Maximization Algorithm
#'
#' The E-step computes the responsibilities for each data point, which represent
#' the probability of each data point belonging to each cluster based on the current
#' parameters of the Gaussian Mixture Model (GMM).
#'
#' @param X A matrix or data frame of observations where rows are samples and columns are features.
#' @param K An integer specifying the number of clusters in the Gaussian Mixture Model.
#' @param proportions A vector of mixing proportions for each Gaussian component in the GMM.
#' @param mu A list of mean vectors for each Gaussian component in the GMM.
#' @param sigma A list of covariance matrices for each Gaussian component in the GMM.
#' @return A matrix of responsibilities (also known as posterior probabilities), where each row
#'   corresponds to a data point and each column corresponds to a Gaussian component (cluster).
#'   The value at position (i, j) represents the probability that data point i belongs to cluster j.
#' @export

E_step <- function(X, K, proportions, mu, sigma) {
  nb_observations <- dim(X)[1]
  likelihoods <- matrix(0, nrow = nb_observations, ncol = K)
  epsilon <- 1e-6

  for (k in 1:K) {
    likelihoods[, k] <- proportions[k] * dmvnorm(X, mean = mu[[k]], sigma = sigma[[k]] + epsilon)
  }

  row_sums <- rowSums(likelihoods)
  t_i_k <- sweep(likelihoods, 1, row_sums, FUN = "/")
  return(t_i_k)
}
