#' Initialize Parameters for the EM Algorithm
#'
#' This function initializes the parameters for the Expectation-Maximization (EM) algorithm.
#' It performs multiple initializations and selects the best set of parameters based on the
#' computed loss.
#'
#' @param X A matrix or data frame of observations where rows are samples and columns are features.
#' @param K An integer specifying the number of clusters.
#' @param nb_initializations An integer specifying the number of initializations to try. Defaults to 10.
#' @param nb_iter_init_step An integer specifying the number of iterations for the initialization step. Defaults to 10.
#' @param init_method A character string specifying the initialization method. One of "random" (default) or "kmeans".
#' @return A list containing the best parameters:
#'   \item{proportions}{A vector of mixing proportions for the GMM components.}
#'   \item{mu}{A list of mean vectors for each Gaussian component.}
#'   \item{sigma}{A list of covariance matrices for each Gaussian component.}
#' @export

initialize_parameters <- function(X, K, nb_initializations, nb_iter_init_step, init_method = "random") {
  nb_observations <- dim(X)[1]
  nb_features <- dim(X)[2]
  best_loss <- -Inf
  best_params <- NULL

  for (initialization in 1:nb_initializations) {
    cat("Initialization number: ", initialization, "\n")

    proportions <- rep(1 / K, K)
    mu <- vector("list", length = K)
    sigma <- vector("list", length = K)

    if (init_method == "kmeans") {
      kmeans_result <- kmeans(X, centers = K)
      for (k in 1:K) mu[[k]] <- kmeans_result$centers[k, ]
      sigma <- lapply(1:K, function(x) diag(nb_features))
    } else {
      for (k in 1:K) {
        mu[[k]] <- X[sample(1:nb_observations, 1), ]
        sigma[[k]] <- diag(nb_features)
      }
    }

    for (iteration in 1:nb_iter_init_step) {
      t_i_k <- E_step(X, K, proportions, mu, sigma)
      params <- M_step(X, t_i_k)
      proportions <- params$proportions
      mu <- params$mu
      sigma <- params$sigma
    }

    current_loss <- compute_loss(X, K, proportions, mu, sigma)
    cat("Loss for this initialization: ", current_loss, "\n")

    if (current_loss > best_loss) {
      best_loss <- current_loss
      best_params <- list(proportions = proportions, mu = mu, sigma = sigma)
    }
  }

  cat("Best initialization with loss:", best_loss, "\n")
  return(best_params)
}
