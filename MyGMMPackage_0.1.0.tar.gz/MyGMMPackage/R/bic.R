#' bic

#' Compute the Bayesian Information Criterion (BIC)
#'
#' This function computes the Bayesian Information Criterion (BIC) given the number of observations,
#' the number of model parameters, and the log-likelihood of the model.
#'
#' @param nb_observations The number of observations (data points).
#' @param nb_model_parameters The number of model parameters (e.g., Gaussian Mixture Model parameters).
#' @param log_likelihood The log-likelihood of the model.
#' @return A numeric value representing the BIC of the model.
#' @export
bic <- function(nb_observations, nb_model_parameters, log_likelihood) {
  bic_value <- log(nb_observations) * nb_model_parameters - 2 * log_likelihood
  return(bic_value)
}
