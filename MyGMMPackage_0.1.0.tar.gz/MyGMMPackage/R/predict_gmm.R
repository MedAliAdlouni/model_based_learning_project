#' predict_gmm

#' @param X_test A matrix or data frame of test data where rows are samples and columns are features.
#' @param proportions A vector of the mixing proportions for each Gaussian component.
#' @param mu A list of mean vectors for each Gaussian component.
#' @param sigma A list of covariance matrices for each Gaussian component.
#' @param K An integer specifying the number of clusters.
#' @return A vector of predicted cluster labels based on the highest posterior probability.
#'
#' @export
predict_gmm <- function(X_test, proportions, mu, sigma, K) {
  t_i_k <- E_step(X_test, K = K, proportions = proportions, mu = mu, sigma = sigma)
  # Assign each data point to the cluster with the highest likelihood
  maximum_a_posteriori <- apply(t_i_k, 1, function(row) which.max(row))
  return(maximum_a_posteriori)
}
