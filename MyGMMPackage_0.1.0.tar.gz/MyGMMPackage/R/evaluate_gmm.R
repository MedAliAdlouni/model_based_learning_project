#' evaluate_gmm

#' Evaluate the performance of the GMM clustering
#'
#' This function evaluates the performance of the GMM clustering by comparing the predicted cluster
#' assignments to the true labels using a confusion matrix. It calculates the accuracy and returns
#' the matched clusters.
#'
#' @param y_true A vector of true cluster labels.
#' @param y_predic A vector of predicted cluster labels.
#' @return A list containing:
#'   - `predicted_clusters`: The predicted cluster assignments after matching.
#'   - `confusion_matrix`: A confusion matrix comparing true and predicted labels.
#'   - `matching`: The optimal matching of predicted to true labels.
#'   - `accuracy`: The accuracy of the clustering.
#' @export
evaluate_gmm <- function(y_true, y_predic) {
  # Predicted clusters
  predicted_clusters <- y_predic

  # Find optimal correspondence between labels and clusters
  confusion_matrix <- table(predicted_clusters, y_true)
  matching <- solve_LSAP(confusion_matrix, maximum = TRUE)

  # Reassign the clusters according to the correspondence
  aligned_clusters <- matching[predicted_clusters]

  # Evaluate the accuracy
  accuracy <- mean(aligned_clusters == y_true)

  confusion_matrix <- table(aligned_clusters, y_true)

  # Return the results
  return(list(
    predicted_clusters = aligned_clusters,
    confusion_matrix = confusion_matrix,
    matching = matching,
    accuracy = accuracy
  ))
}
