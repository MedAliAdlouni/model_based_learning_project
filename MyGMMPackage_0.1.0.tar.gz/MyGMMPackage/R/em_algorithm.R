#' Expectation-Maximization (EM) Algorithm for GMM
#'
#' This function implements the EM algorithm for fitting a Gaussian Mixture Model (GMM).
#'
#' @param X A matrix or data frame of observations where rows are samples and columns are features.
#' @param K An integer specifying the number of clusters.
#' @param model A character string indicating the model type. Defaults to "basic".
#' @param nb_initializations An integer specifying the number of initializations to try. Defaults to 10.
#' @param max_iterations An integer specifying the maximum number of iterations for the EM algorithm. Defaults to 100.
#' @param loss_treshold A numeric value for the convergence criterion based on loss difference. Defaults to 1e-6.
#' @param plot_losses A logical value indicating whether to plot the loss evolution. Defaults to TRUE.
#' @param nb_iter_init_step An integer specifying the number of iterations for the initialization step. Defaults to 10.
#' @param init_method A character string indicating the initialization method. Defaults to "random".
#' @return A list containing:
#'   \item{losses}{A numeric vector of loss values across iterations.}
#'   \item{proportions}{A vector of mixing proportions for the GMM components.}
#'   \item{mu}{A matrix of means for the GMM components.}
#'   \item{sigma}{A list of covariance matrices for the GMM components.}
#'   \item{last_t_i_k}{The final posterior probabilities for each sample belonging to each cluster.}
#'   \item{bic}{The Bayesian Information Criterion (BIC) value for the model.}
#'   \item{maximum_a_posteriori}{A vector of cluster assignments based on the highest posterior probability.}
#' @export

em_algorithm <- function(X, K, model = "basic", nb_initializations = 10, max_iterations = 100,
                         loss_treshold = 1e-6, plot_losses = TRUE, nb_iter_init_step = 10, init_method = "random") {

  nb_observations <- dim(X)[1]
  nb_features <- dim(X)[2]

  nb_model_parameters <- compute_nb_model_params(K, model, nb_features)
  cat("Number of model parameters: ", nb_model_parameters, "\n")

  params <- initialize_parameters(X, K, nb_initializations, nb_iter_init_step, init_method)
  if (is.null(params)) stop("Initialization failed. Parameters not returned.")

  proportions <- params$proportions
  mu <- params$mu
  sigma <- params$sigma

  losses <- numeric(max_iterations + 1)
  first_loss <- compute_loss(X, K, proportions, mu, sigma)
  losses[1] <- first_loss
  cat("Initial Loss: ", first_loss, "\n")

  last_t_i_k <- NULL

  for (iteration in 1:max_iterations) {
    cat("Iteration:", iteration, "\n")

    t_i_k <- E_step(X, K, proportions, mu, sigma)
    last_t_i_k <- t_i_k
    params <- M_step(X, t_i_k, model = model)

    proportions <- params$proportions
    mu <- params$mu
    sigma <- params$sigma

    current_loss <- compute_loss(X, K, proportions, mu, sigma)
    losses[iteration + 1] <- current_loss
    cat("Current Loss: ", current_loss, "\n")

    if (abs(losses[iteration + 1] - losses[iteration]) < loss_treshold) {
      cat("Converged at iteration", iteration, "with loss", current_loss, "\n")
      break
    }
  }

  losses <- losses[1:iteration]
  bic_value <- bic(nb_observations, nb_model_parameters, tail(losses, 1))

  if (plot_losses) {
    plot(losses[-1], type = "o", col = "blue", xlab = "Iteration", ylab = "Log-Loss",
         main = paste("Loss Evolution in EM Algorithm - Model:", model))
  }

  maximum_a_posteriori <- apply(last_t_i_k, 1, function(row) which.max(row))
  cat("Maximum a posteriori labels:", maximum_a_posteriori, "\n")

  return(list(losses = losses, proportions = proportions, mu = mu, sigma = sigma,
              last_t_i_k = last_t_i_k, bic = bic_value, maximum_a_posteriori = maximum_a_posteriori))
}
