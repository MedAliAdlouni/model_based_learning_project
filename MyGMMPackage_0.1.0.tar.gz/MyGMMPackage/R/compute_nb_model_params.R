
#' compute_nb_model_params

#' Compute the number of model parameters for different GMM models
#'
#' @param K An integer specifying the number of Gaussian components (clusters).
#' @param model A character string specifying the model type. Can be one of "basic", "homoscedastic", "CEM", or "SEM".
#' @param nb_features An integer specifying the number of features in the dataset.
#'
#' @return An integer representing the number of model parameters based on the specified model type.
#'
#' @export
compute_nb_model_params <- function(K, model, nb_features){
  nb_model_parameters <- NA

  if (model == "basic"){
    nb_model_parameters <- K * (1 + nb_features + nb_features * (nb_features + 1) / 2)
  }

  if (model == "homoscedastic"){
    nb_model_parameters <- K * (1 + nb_features) + (nb_features * (nb_features + 1) / 2)
  }

  if (model == "CEM"){
    # Adjusted formula for CEM
    nb_model_parameters <- K * (1 + nb_features) + (nb_features * (nb_features + 1) / 2) + K
    # Add any latent variable parameters or additional complexity here
  }

  if (model == "SEM"){
    # Adjusted formula for SEM
    nb_model_parameters <- K * (1 + nb_features) + nb_features * (nb_features + 1) / 2
    # Add parameters for structural equations if needed
  }

  return(nb_model_parameters)
}

